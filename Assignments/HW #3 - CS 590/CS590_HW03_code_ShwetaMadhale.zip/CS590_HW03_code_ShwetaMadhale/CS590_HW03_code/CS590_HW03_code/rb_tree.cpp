//Shweta Madhale, CWID : 20015921
#include "rb_tree.h"
#include <list>
#include <iostream>

using namespace std;

//Constructor
rb_tree::rb_tree(){ 

  T_nil = new rb_tree_node();
  T_nil->color = RB_BLACK;  //Color of the node
  T_nil->p = T_nil;         //Parent node
  T_nil->left = T_nil;      //Left child node
  T_nil->right = T_nil;     //Right child node
  T_root = T_nil;           //Root node
  rbt.i_duplicate = 0;      //Counts duplicate nodes
  rbt.i_case_1 = 0;         //Counts case 1 insertions 
  rbt.i_case_2 = 0;         //Counts case 2 insertions
  rbt.i_case_3 = 0;         //Counts case 3 insertions
  rbt.i_left_rotate = 0;    //Counts left rotations
  rbt.i_right_rotate = 0;   //Counts right rotations

} 

//Destructor
rb_tree::~rb_tree(){ 
  remove_all(T_root);
  delete T_nil;
} 

//Remove all nodes in the RBT recursively
void rb_tree::remove_all(rb_tree_node* x){ 

  if (x != T_nil){
      remove_all(x->left);
      remove_all(x->right);

      delete x;
  }

} 


//Wrapper: Insert a node with given key in the RBT
void rb_tree::insert(int key, rb_tree_i_info& t_info){ 

  //Creating a node having the given key value
  rb_tree_node* z;    

  z = new rb_tree_node;
  z->color = RB_BLACK;
  z->key = key;

  insert(z, t_info);

} 

//Insert the node created in wrapper function with given key into the RBT
void rb_tree::insert(rb_tree_node* z, rb_tree_i_info& t_info){ 

  rb_tree_node* x;
  rb_tree_node* y;

  y = T_nil;
  x = T_root;

  while (x != T_nil){

      y = x;

      if(z->key == x->key){
        //RBT has node with same key as the new node -> duplicate node 
        rbt.i_duplicate++;
        return;
      }
      
      //Finding position to insert the new node where it follows the BST property(colors are fixed later)
      if (z->key < x->key)
	      x = x->left;
      else
	      x = x->right;
    }

  z->p = y;

  if (y == T_nil){
    //No node exists in the RBt, insert new node as the root
    T_root = z;
  }else{
      if (z->key < y->key){
	      y->left = z;
      }
      else{
	      y->right = z;
      }
    }

  z->left = T_nil;
  z->right = T_nil;
  z->color = RB_RED;

  //Fix the RBT properties
  insert_fixup(z, t_info);

} 

void rb_tree::insert_fixup(rb_tree_node*& z, rb_tree_i_info& t_info)
{ 
  rb_tree_node* y;

  while (z->p->color == RB_RED){
    if (z->p == z->p->p->left){
      y = z->p->p->right;

      if (y->color == RB_RED){
        //Case 1
        z->p->color = RB_BLACK;		
        y->color = RB_BLACK;
        z->p->p->color = RB_RED;
        z = z->p->p;
        rbt.i_case_1++;       //Increment case 1 insertion counter
      }else{
          if(z == z->p->right){
            // Case 2
            z = z->p;			
            left_rotate(z);
            rbt.i_case_2++;   //Increment case 2 insertion counter
          }else{
            //Case 3
            z->p->color = RB_BLACK;		
            z->p->p->color = RB_RED;
            right_rotate(z->p->p);
            rbt.i_case_3++;   //Increment case 1 insertion counter
          }
      }
    }else{
        y = z->p->p->left;

        if (y->color == RB_RED){
          //Case 1
          z->p->color = RB_BLACK;		
          y->color = RB_BLACK;
          z->p->p->color = RB_RED;
          z = z->p->p;
          rbt.i_case_1++;       //Increment case 1 insertion counter
        }else{
            if (z == z->p->left){
              //Case 2
              z = z->p;			
              right_rotate(z);
              rbt.i_case_2++;   //Increment case 2 insertion counter
            }else{
              //Case 3
              z->p->color = RB_BLACK;		
              z->p->p->color = RB_RED;
              left_rotate(z->p->p);
              rbt.i_case_3++;   //Increment case 1 insertion counter
            }   
        } 
	    }
    }
  T_root->color = RB_BLACK;
} 

//Perform left rotation on nodes to maintain RBT property
void rb_tree::left_rotate(rb_tree_node* x){

  rb_tree_node* y;
  rbt.i_left_rotate++;  //Increment left rotation counter
  y = x->right;			    //Set y
  x->right = y->left;		//Turn y's left subtree into x's right subtree
  if (y->left != T_nil){
    y->left->p = x;
  }

  y->p = x->p;			    //Link x's parent to y
  if (x->p == T_nil){
    T_root = y;
  }else{
      if (x == x->p->left){
        x->p->left = y;
      }else{
	      x->p->right = y;
      }
  }

  y->left = x;			  //Put x on y's left
  x->p = y;
} 


//Perform right rotation on the nodes to maintain RBT properties
void rb_tree::right_rotate(rb_tree_node* x){ 

  rb_tree_node* y;
  rbt.i_right_rotate++;   //Increment right rotation counter

  y = x->left;			      //Set y
  x->left = y->right;		  //Turn y's right subtree into x's left subtree
  if (y->right != T_nil){
    y->right->p = x;
  }

  y->p = x->p;			      //Link x's parent to y
  if (x->p == T_nil){
    T_root = y;
  }else{
      if (x == x->p->right){
        x->p->right = y;
      }else{
        x->p->left = y;
      }
  }

  y->right = x;			      //Put x on y's right
  x->p = y;
} 

//Inorder walk of the RBT
void rb_tree::inorder_output(rb_tree_node* x, int level){ 

  if (x != T_nil)
    {
      inorder_output(x->left, level+1);
      cout << "(" << x->key << "," << level << "," 
	   << ((x->color == RB_RED) ? "R" : "B") << ")" << endl;
      inorder_output(x->right, level+1); 
    }
}


//Structured output of RBT
void rb_tree::output(rb_tree_node* x, int r_level){ 

  list< pair<rb_tree_node*,int> > l_nodes;
  pair<rb_tree_node*,int> c_node;
  int c_level;

  c_level = r_level;
  l_nodes.insert(l_nodes.end(), pair<rb_tree_node*,int>(x, r_level));

  while (!l_nodes.empty())
    {
      c_node = *(l_nodes.begin());

      if (c_level < c_node.second)
	{
	  cout << endl;
	  c_level = c_node.second;
	}

      cout << "(" << c_node.first->key << "," 
	   << ((c_node.first->color == RB_RED) ? "R" : "B");

      if (c_node.first->p == T_nil)
	cout << ",ROOT) ";
      else
        cout << ",P:" << c_node.first->p->key << ") ";

      if (c_node.first->left != T_nil)
	l_nodes.insert(l_nodes.end(), pair<rb_tree_node*,int>(c_node.first->left, 
							      c_node.second+1));
      if (c_node.first->right != T_nil)
	l_nodes.insert(l_nodes.end(), pair<rb_tree_node*,int>(c_node.first->right, 
							      c_node.second+1));
      l_nodes.erase(l_nodes.begin());
    }

  cout << endl;
} 


//Traversing the tree recursively in ascending order(starts from the leftmost node and moving up)
int rb_tree::inorderTraversal(rb_tree_node* x, int* array, int idx){
  if(x != T_nil){
    //Find the left-most node(smallest key)
    idx = inorderTraversal(x->left, array, idx);
    //Update the value in ascending manner in the array
    array[idx] = x->key;
    idx = idx + 1;
    //Move to the right node on same level and recurse
    idx = inorderTraversal(x->right, array, idx);
  }
  return idx;
}


//Question 2 : Convert the BST into an array in ascending manner
int rb_tree::convert(int* array, int n){
  n = inorderTraversal(T_root, array, 0);
  return n; //Will return the new size of array(no duplicated nodes)
  
}

//Question 3 : Returns the count for duplicate nodes, insertion cases, and rotations
int rb_tree::counters(int i){

  if(i == 0){
    //Return duplicate nodes count
    return rbt.i_duplicate;
  }else if(i == 1){
    //Return case 1 insertions count
    return rbt.i_case_1;
  }else if(i == 2){
    //Return case 2 insertions count
    return rbt.i_case_2;
  }else if(i == 3){
    //Returns case 3 insertions count
    return rbt.i_case_3;
  }else if(i == 4){
    //Return left rotation count
    return rbt.i_left_rotate;
  }else{
    //Return right rotation count
    return rbt.i_right_rotate;
  }
}


//Question 4 : Find the black height(number of black nodes)
int rb_tree::check_black_height(rb_tree_node* x)
{
  return getBlackHeight(x, 0);
}


//Traverse and find the number of black nodes in the path to node
int rb_tree::getBlackHeight(rb_tree_node* x, int height){
  if(x != T_nil){
    //Find leftmost node
    int leftHeight = getBlackHeight(x->left, height);
    //Increment height if the node has black color
    if(x->color == RB_BLACK){
      height++;
    }
    //Move up
    int rightHeight = getBlackHeight(x->right, height);

    //Return the height
    return max(leftHeight, rightHeight)+1;
    
  }else{
    //Tree is empty
    return 0;
  }
  
}
