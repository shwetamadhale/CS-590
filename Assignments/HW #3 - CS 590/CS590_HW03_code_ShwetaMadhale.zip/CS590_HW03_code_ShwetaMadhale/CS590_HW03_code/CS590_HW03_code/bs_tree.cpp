// Shweta Madhale, CWID : 20015921

#include "bs_tree.h"
#include <list>
#include <iostream>

using namespace std;

//Constructor
bs_tree::bs_tree(){ 
  T_nil = new bs_tree_node();
  T_nil->p = T_nil;       //Parent node
  T_nil->left = T_nil;    //Left child node
  T_nil->right = T_nil;   //Right child node
  T_root = T_nil;         //Root node
  bst.i_duplicate = 0;    //Counter for duplicate nodes
} 


//Destructor
bs_tree::~bs_tree(){ 

  remove_all(T_root);
  delete T_nil;

} 

//Recursively remove all nodes in the tree
void bs_tree::remove_all(bs_tree_node* x){ 

  if (x != T_nil){
      remove_all(x->left);
      remove_all(x->right);

      delete x;
  }
} 

//Wrapper: Insert a new node with given key in the BST
void bs_tree::insert(int key, bs_tree_i_info& t_info){ 

  bs_tree_node* z;  //Node to insert with given key
  
  z = new bs_tree_node;
  z->key = key;

  insert(z, t_info);

}


//Insert new node in the BST
void bs_tree::insert(bs_tree_node* z, bs_tree_i_info& t_info){ 

  bs_tree_node* x;
  bs_tree_node* y;

  y = T_nil;
  x = T_root;

  //Find where the new node should be inserted such that it follows the BST propeties
  while (x != T_nil){

      y = x;
      if(z->key == x->key){
        bst.i_duplicate++;  //Node with given key already exists -> duplicate
        return;
      }else if (z->key < x->key)
	      x = x->left;  //Search deeper in the left subtree
      else
	      x = x->right; //Search deeper in the right subtree
    }

  z->p = y;

  if (y == T_nil){
    //Tree is empty, insert new node as the root
    T_root = z;
  }else{ 
      //Update new node as child node of the appropriate parent node
      if (z->key < y->key){
	      y->left = z;
      }
      else{
	      y->right = z;
      }
    }

  z->left = T_nil;
  z->right = T_nil;

} 


//Traversing the tree recursively in ascending order(starts from the leftmost node and moving up)
int bs_tree::inorderTraversal(bs_tree_node* x, int* array, int idx){
  if(x != T_nil){

    //Find the left-most node(smallest key)
    idx = inorderTraversal(x->left, array, idx);
    //Update the value in ascending manner in the array
    array[idx] = x->key;
    idx = idx + 1;
    //Move to the right node on same level and recurse
    idx = inorderTraversal(x->right, array, idx);
  }
  return idx;

}

//Inorder walk of the BST
void bs_tree::inorder_output(bs_tree_node* x, int level){ 

  if (x != T_nil)
    {
      inorder_output(x->left, level+1);
      cout << "(" << x->key << "," << level << ")" << endl;
      inorder_output(x->right, level+1); 
    }
}

//Structured output of BST
void bs_tree::output(bs_tree_node* x, int r_level){ 

  list< pair<bs_tree_node*,int> > l_nodes;
  pair<bs_tree_node*,int> c_node;
  int c_level;

  c_level = r_level;
  l_nodes.insert(l_nodes.end(), pair<bs_tree_node*,int>(x, r_level));

  while (!l_nodes.empty())
    {
      c_node = *(l_nodes.begin());

      if (c_level < c_node.second)
	{
	  cout << endl;
	  c_level = c_node.second;
	}

      cout << "(" << c_node.first->key;

      if (c_node.first->p == T_nil)
	cout << ",ROOT) ";
      else
        cout << ",P:" << c_node.first->p->key << ") ";

      if (c_node.first->left != T_nil)
	l_nodes.insert(l_nodes.end(), pair<bs_tree_node*,int>(c_node.first->left, 
							      c_node.second+1));
      if (c_node.first->right != T_nil)
	l_nodes.insert(l_nodes.end(), pair<bs_tree_node*,int>(c_node.first->right, 
							      c_node.second+1));
      l_nodes.erase(l_nodes.begin());
    }

  cout << endl;
} 


//Question 2 : Convert the BST into an array in ascending manner
int bs_tree::convert(int* array, int n){

  n = inorderTraversal(T_root, array, 0);
  return n; //Will return the new size of array(no duplicated nodes)

}


//Question 3 : Returns the count for duplicate nodes
int bs_tree::counter(){

  return bst.i_duplicate;

}



