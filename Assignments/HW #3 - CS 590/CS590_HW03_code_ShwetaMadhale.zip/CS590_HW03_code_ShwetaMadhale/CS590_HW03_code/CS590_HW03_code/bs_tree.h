#ifndef __BS_TREE_H__
#define __BS_TREE_H__

struct bs_tree_node {
  int key;
  bs_tree_node*	left;
  bs_tree_node*	right;
  bs_tree_node*	p;
};

struct bs_tree_i_info{
  int i_duplicate;

  void reset()
    { i_duplicate = 0; }
};


class bs_tree{ 
  protected:
    bs_tree_node*	T_nil;
    bs_tree_node*	T_root;
    bs_tree_i_info bst;

  public:
    bs_tree();
    ~bs_tree();

    void insert(int, bs_tree_i_info&);  //insert new node with given key
    int convert(int*, int);             //Convert BST to an array in ascending order
    int counter();                      //Get count of duplicate nodes


  protected:
    void insert(bs_tree_node*, bs_tree_i_info&);
    void remove_all(bs_tree_node*);
    void inorder_output(bs_tree_node*, int);
    void output(bs_tree_node*, int);
    int inorderTraversal(bs_tree_node* , int*, int);
    
};


#endif
