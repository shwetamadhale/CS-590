#include <cstring>
#include <iostream>
#include <limits.h>

#include "dynprog.h"

using namespace std;


/*
 * Q.1 - Bottom up implementation of Smith-Waterman algorithm
 */
void SW_bottomUp(char* X, char* Y, char** P, int** H, int n, int m){


    int p1 = 0, p2 = 0, p3 = 0;

    //Initialize H and P tables 
    for(int i = 0; i <= n; i++ ){
        H[i][0] = 0;
        P[i][0] = 0;
    }

    for(int j = 0; j <= m; j++){
        H[0][j] = 0;
        P[0][j] = 0;
    }

    //Compute values and fill the table
    for(int i = 1; i <= n; i++){
        for(int j = 1; j <= m; j++){

            if(X[i-1] == Y[j-1]){
                //The characters are same, so increment
                p1 = H[i-1][j-1] + 2; 
            }else{
                //The characters are not the same, so decrement
                p1 = H[i-1][j-1] - 1;
            }

            p2 = H[i-1][j] - 1;
            p3 = H[i][j-1] - 1;

            //Find maximum value of p1, p2, and p3, and assign to the H table
            H[i][j] = p1 > p2? (p1> p3? p1: p3): (p2 > p3? p2: p3);

            //According to value in H, assign direction in P, p1~Diagonal, p2~Above, p3~Left
            if(H[i][j] == p1){
                P[i][j] = 'd';
            }else{
                if(H[i][j] == p2){
                    P[i][j] = 'a';
                }else{
                    P[i][j] = 'l';
                }
            }

        }
    }

}

/*
 * Q.2 - Top-down with memoization implementation of Smith-Waterman algorithm
 */
void memoized_SW(char* X, char* Y, char** P, int** H, int n, int m){
    //Wrapper class
    //Initialize H and P tables 
    for(int i = 0; i <= n; i++ ){
        H[i][0] = 0;
        P[i][0] = 0;
    }

    for(int j = 0; j <= m; j++){
        H[0][j] = 0;
        P[0][j] = 0;
    }

    //Assign sentinel value (-infinity) 
    for(int i = 1; i <= n; i++){
        for(int j = 1; j <= m; j++){
            H[i][j] = INT_MIN;
        }
    }

    //Call main recursive function
    memoized_SW_AUX(X, Y, P, H, n, m);
}

/*
 * Auxilary recursive function of top-down with memoization implementation of Smith-Waterman algorithm
 */
void memoized_SW_AUX(char* X, char* Y, char** P, int** H, int n, int m){
	int p1, p2, p3 = 0;

    //If the value in H table is sentinel, then recursively continue
    if(H[n-1][m-1] == INT_MIN){
        memoized_SW_AUX(X, Y, P, H, n-1, m-1);
    }

    if(X[n-1] == Y[m-1]){
        //Characters in both string are same, so increment
        p1 = H[n-1][m-1] + 2;
    }else{
        //Characters in both string are not the same, so decrement
        p1 = H[n-1][m-1] - 1;
    }
    
    //Recursively find value of p2
    if(H[n-1][m] == INT_MIN){
        memoized_SW_AUX(X, Y, P, H, n-1, m);
    }
    p2 = H[n-1][m] - 1;

    //Recursively find value of p3
    if(H[n][m-1] == INT_MIN){
        memoized_SW_AUX(X, Y, P, H, n, m-1);
    }
    p3 = H[n][m-1] - 1;
    

    //Compare values of p1, p2, and p3. Use the maximum value of the three
    H[n][m] = p1 > p2? (p1> p3? p1: p3): (p2 > p3? p2: p3);


    //Assign direction based on value in the H table, d ~ diagonal, a ~ above, l ~ left
    if(H[n][m] == p1){
        P[n][m] = 'd';
    }else {
        if(H[n][m] == p2){
            P[n][m] = 'a';
        }else{
            P[n][m] = 'l';
        }
    }

    return;

}



/*
 * Q. 3 - Print X'
 */
void print_Seq_Align_X(char* X, char** P, int n, int m){
    //Diagonal
    if (P[n][m] == 'd'){
            print_Seq_Align_X(X, P, n-1, m-1);
            cout << X[n-1];
        }
        else if (P[n][m] == 'a'){
            //Above
            print_Seq_Align_X(X, P, n-1, m);
            cout << X[n-1];
        }else if (P[n][m] == 'l'){
            //Left
            print_Seq_Align_X(X, P, n, m-1);
            cout << '-';
        }
}

/*
 * Q. 3 - Print Y'
 */
void print_Seq_Align_Y(char* Y, char** P, int n, int m){
	if (P[n][m] == 'd'){
        //Diagonal
        print_Seq_Align_Y(Y, P, n-1, m-1);
        cout << Y[m - 1];
    }else if (P[n][m] == 'a'){
        //Above
        print_Seq_Align_Y(Y, P, n-1, m);
        cout << '-';
    }else if (P[n][m] == 'l'){
        //Left
        print_Seq_Align_Y(Y, P, n, m-1);
        cout << Y[m-1];
    }
}
