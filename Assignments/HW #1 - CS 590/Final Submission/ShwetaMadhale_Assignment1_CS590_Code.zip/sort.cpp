//Shweta Madhale
//CWID : 20015921
#include <cstdio>
#include <cstdlib>
#include <limits>
#include "sort.h"


int ivector_length(int* v, int n){
  int sum;

  sum = 0;
  for (int i = 0; i < n; i++)
    sum += (v[i] < 0) ? -v[i] : v[i];

  return sum;
}

/*
 * insertion sort
 */
void insertion_sort(int** A, int n, int l, int r){ 
  int i;
  int* key;

  for (int j = l+1; j <= r; j++){
      key = A[j];
      i = j - 1;

      while ((i >= l) && (ivector_length(A[i], n) > ivector_length(key, n))){
	  A[i+1] = A[i];
	  i = i - 1;
      }

      A[i + 1] = key;
  }
}

/*
 *Creating new function to compute length of the vectors and return the array containing those lengths
 *Will be helpful to directly fetch values from the array than computing vector length for each comparison
 */
int* computeLength(int** A, int n, int l, int r){
    //Finding the size of the vector and assigning new one with that size
    int vecSize = r - l + 1; 
    int* findLength =  new int[vecSize];
	
    //Getting each value from given vector and calling the 'ivector_length()' function to compute length. Also, storing the length corresponding to its position to the vector 	
    for(int i = l; i <= r; i++){
        findLength[i] = ivector_length(A[i], n);
    }

    //Returning vector containing length of vectors
    return findLength;
}


void insertion_sort_im(int** A, int n, int l, int r){
    //Storing lengths of the vectors using 'computeLength()' 
    int* compLength = computeLength(A, n, l, r);
    //This will keep track of vector index which is preceeding the key
    int i;
    //Two keys which will keep track of indexes in the given vector and vector containing lengths of items of given vector respectively
    int* key1, key2;

    //Continue like naive insertion sort
    
    //Loop to compare and accordingly swap values
    for (int j = l + 1; j <= r; j++){
    	//Start by considering index 0 item to be sorted, so starts with 1's item
        key1 = A[j];
        //Keeps track of index in length vector
        key2 = compLength[j-l];
        //Holds the index one before key1
        i = j - 1;

	//If 0th index has not been reached and the vector length of item with lower index is greater than the one with higher index, then swapping will take place
        while ((i >= l) && (key2 < compLength[i])){
            //Update new values
            A[i + 1] = A[i];
            compLength[i + 1] = compLength[i];
            i = i - 1;
        }
        //Update new values
        A[i + 1] = key1;
        compLength[i + 1] = key2;
   }

}


/*
*   Improved Merge Sort 
*/

//merge() function which will combine the divided arrays, behaves like conquer stage
void merge(int** A, int* compLength, int n, int p, int q, int r){
    /*
     * A : Main vector
     * compLength : Array holding length for each item in main vector 
     * n : size of vector
     * p : Starting index 
     * q : Mid index
     * r : End index
     * 
     * There will be two subarrays, from p to q, other will be from q+1, r
     */
     
    //Computing the size of subarrays
    int n1 = q - p + 1;
    int n2 = r - q;
    
    //Creating two subarrays-left and right
    //Creating two subarrays for holding lengths for each subarray
    int** L = new int*[n1];	//Left subarray
    int* Llen = new int[n1 + 1];	//Length vector for left subarray

    int** R = new int*[n2];	//Right subarray
    int* Rlen = new int[n2 + 1];	//Length vector for right subarray

    //Copying from main vector to each subarray
    
    //Constructing left subarray and its length vector 
    for(int s = 0; s < n1; s++){
    	L[s] = new int[n];
        L[s] = A[p + s];
        Llen[s] = compLength[p + s];
    }

    //Constructing right subarray and its length vector 
    for(int t = 0; t < n1; t++){
    	R[t] = new int[n];
        R[t] = A[q + t + 1];
        Rlen[t] = compLength[q + t + 1];
    }

    //Put sentinels(infinity) at the ends of each subarray
    Llen[n1] = std::numeric_limits<int>::max();
    Rlen[n2] = std::numeric_limits<int>::max();


    /*
     *Simultaneously comparing values(lengths) of each item in the left and right subarray
     *Depending on the lengths(from length vectors) copy corresponding items to the main vector
     */
    int i = 0, j = 0;

    for(int k = p; k <= r; k++){
    	//Comparing length of items at index 'i' in left subarray and 'j' in right subarray
        if(Llen[i] <= Rlen[j]){
            //Left subarray holds smaller length so copy corresponding value to main vector
            A[k] = L[i];
            compLength[k] = Llen[i];
            i++;
        }else{
            //Right subarray holds smaller length so copy corresponding value to main vector
            A[k] = R[j];
            compLength[k] = Rlen[j];
            j++;
        }
    }

}

/*
 *Creating new function to pass the vector length as an parameter, this will significantly reduce computation time
 */
void sortMerge(int** A, int* compLength, int n, int p, int r){
    //Find the midpoint of the given vector
    int q = 0;
    //Until the start index is smaller than end index, keep dividing main vector in left and right subarrays recursively
    if(p < r){
    	//Find middle index
        q = (p + r)/2;
        //Two subarrays will have indices: from p to q, and from q+1 to r
        sortMerge(A, compLength, n, p, q);
        sortMerge(A, compLength, n, q+1, r);
        //Calling the merge function to combine the divided arrays
        merge(A, compLength, n, p, q, r);
    }
}
/*
*   TO IMPLEMENT: Improved Merge Sort for problem 2.
*/
void merge_sort(int** A, int n, int p, int r)
{
    //Storing the array containing length of each item in main vector
    int* compLength = computeLength(A, n, p, r);
    //Calling similar function but passing length vector as a parameter
    sortMerge(A, compLength, n, p, r);
}

/*
 * Simple function to check that our sorting algorithm did work
 * -> problem, if we find position, where the (i-1)-th element is 
 *    greater than the i-th element.
 */
bool check_sorted(int** A, int n, int l, int r)
{
  for (int i = l+1; i <= r; i++)
    if (ivector_length(A[i-1], n) > ivector_length(A[i], n))
      return false;
  return true;
}


/*
 * generate sorted/reverse/random arrays of type hw1type
 */
int** create_ivector(int n, int m)
{
  int** iv_array;

  iv_array = new int*[m];
  for (int i = 0; i < m; i++)
    iv_array[i] = new int[n];

  return iv_array;
}

void remove_ivector(int** iv_array, int m)
{
  for (int i = 0; i < m; i++)
    delete[] iv_array[i];
  delete[] iv_array;
}

int** create_sorted_ivector(int n, int m)
{
  int** iv_array;

  iv_array = create_ivector(n, m);
  for (int i = 0; i < m; i++)
    for (int j = 0; j < n; j++)
      iv_array[i][j] = (i+j)/n;

  return iv_array;
}

int** create_reverse_sorted_ivector(int n, int m)
{
  int** iv_array;

  iv_array = create_ivector(n, m);
  for (int i = 0; i < m; i++)
    for (int j = 0; j < n; j++)
      iv_array[i][j] = ((m-i)+j)/n;

  return iv_array;
}

int** create_random_ivector(int n, int m, bool small)
{
  random_generator rg;
  int** iv_array;

  iv_array = create_ivector(n, m);
  for (int i = 0; i < m; i++)
    for (int j = 0; j < n; j++)
      {
	rg >> iv_array[i][j];
	if (small)
	  iv_array[i][j] %= 100;
	else
	  iv_array[i][j] %= 65536;
      }

  return iv_array;
}

